package com.gwyf.casino;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;

public final class ChipUtil {
    private ChipUtil() {}

    public static int count(PlayerEntity p) {
        int n = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ModItems.CHIP)) n += s.getCount();
        }
        return n;
    }

    public static boolean take(PlayerEntity p, int amount) {
        if (count(p) < amount) return false;
        int left = amount;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size() && left > 0; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ModItems.CHIP)) {
                int d = Math.min(left, s.getCount());
                s.decrement(d);
                left -= d;
            }
        }
        return true;
    }

    public static void give(PlayerEntity p, int amount) {
        while (amount > 0) {
            int n = Math.min(amount, 64);
            p.getInventory().offerOrDrop(new ItemStack(ModItems.CHIP, n));
            amount -= n;
        }
    }
}
