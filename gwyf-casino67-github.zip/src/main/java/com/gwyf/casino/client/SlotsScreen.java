package com.gwyf.casino.client;

import com.gwyf.casino.Ev;
import com.gwyf.casino.GameType;
import com.gwyf.casino.ResultPacket;
import com.gwyf.casino.Rules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.Random;

public class SlotsScreen extends CasinoScreen {
    private static final Item[] SYMBOLS = {Items.APPLE, Items.GOLD_INGOT, Items.BELL, Items.EMERALD, Items.DIAMOND, Items.NETHER_STAR};
    private static final int[] STOP_AT = {16, 24, 32};

    private final Random rng = new Random();
    private final int[] shown = {0, 2, 5};
    private final boolean[] stopped = {true, true, true};
    private int spinTick, resultTick = -1;
    private ResultPacket pending;

    public SlotsScreen(int chips) {
        super(GameType.SLOTS, chips);
    }

    @Override
    protected String hintKey() { return "gwyf.hint.slots"; }

    @Override
    protected void initGame(int left, int top) {
        addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.spin"), b -> spin())
                .dimensions(left + 110, top + 156, 100, 20).build());
    }

    private void spin() {
        if (busy) return;
        if (chips < bet()) {
            setMessage(Text.translatable("gwyf.ui.nochips").getString(), 0xFFFF5555);
            return;
        }
        busy = true;
        chips -= bet();
        message = "";
        pending = null;
        resultTick = -1;
        spinTick = 0;
        stopped[0] = stopped[1] = stopped[2] = false;
        sendAction(Rules.ACT_PLAY, bet(), 0);
        play(SoundEvents.BLOCK_WOODEN_BUTTON_CLICK_ON, 1.0f);
    }

    @Override
    protected void handle(ResultPacket r) {
        if (r.event() == Ev.SLOTS_RESULT) {
            pending = r;
            resultTick = spinTick;
        }
    }

    @Override
    protected void onNoChips() {
        stopped[0] = stopped[1] = stopped[2] = true;
    }

    @Override
    protected void tickGame() {
        if (!busy) return;
        spinTick++;
        for (int i = 0; i < 3; i++) {
            if (stopped[i]) continue;
            if (pending != null && spinTick >= Math.max(STOP_AT[i], resultTick + 4 + i * 8)) {
                stopped[i] = true;
                shown[i] = i == 0 ? pending.a() : (i == 1 ? pending.b() : pending.c());
                play(SoundEvents.BLOCK_WOODEN_BUTTON_CLICK_ON, 1.3f);
            } else if (spinTick % 2 == 0) {
                shown[i] = rng.nextInt(SYMBOLS.length);
            }
        }
        if (pending != null && stopped[0] && stopped[1] && stopped[2]) finish();
    }

    private void finish() {
        busy = false;
        chips = pending.chips();
        int pay = pending.payout();
        if (pay >= bet() && pay > 0) {
            setMessage(Text.translatable("gwyf.ui.payout", pay).getString(), 0xFF55FF55);
            play(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f);
        } else if (pay > 0) {
            setMessage(Text.translatable("gwyf.ui.payout", pay).getString(), 0xFFFFFF55);
        } else {
            setMessage(Text.translatable("gwyf.ui.lose").getString(), 0xFFFF5555);
            play(SoundEvents.ENTITY_VILLAGER_NO, 1.0f);
        }
        pending = null;
    }

    @Override
    protected void drawGame(DrawContext c, int mx, int my, float delta) {
        int bw = 44, gap = 10;
        int x0 = left + (panelW - (3 * bw + 2 * gap)) / 2;
        int y0 = top + 48;
        MatrixStack ms = c.getMatrices();
        for (int i = 0; i < 3; i++) {
            int x = x0 + i * (bw + gap);
            c.fill(x - 2, y0 - 2, x + bw + 2, y0 + bw + 2, 0xFFD4AF37);
            c.fill(x, y0, x + bw, y0 + bw, 0xFF0D0D12);
            ms.push();
            ms.translate(x + 6, y0 + 6, 0);
            ms.scale(2f, 2f, 1f);
            c.drawItem(new ItemStack(SYMBOLS[shown[i]]), 0, 0);
            ms.pop();
        }
        c.fill(x0 - 8, y0 + bw / 2 - 1, x0 + 3 * bw + 2 * gap + 8, y0 + bw / 2 + 1, 0x66FF3030);
    }
}
