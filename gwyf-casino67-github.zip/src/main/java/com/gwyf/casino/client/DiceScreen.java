package com.gwyf.casino.client;

import com.gwyf.casino.Ev;
import com.gwyf.casino.GameType;
import com.gwyf.casino.ResultPacket;
import com.gwyf.casino.Rules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.Random;

public class DiceScreen extends CasinoScreen {
    // pip positions on a 3x3 grid (col,row) per die face
    private static final int[][][] PIPS = {
            {},
            {{1, 1}},
            {{0, 0}, {2, 2}},
            {{0, 0}, {1, 1}, {2, 2}},
            {{0, 0}, {2, 0}, {0, 2}, {2, 2}},
            {{0, 0}, {2, 0}, {1, 1}, {0, 2}, {2, 2}},
            {{0, 0}, {2, 0}, {0, 1}, {2, 1}, {0, 2}, {2, 2}}
    };
    private static final int ROLL_TICKS = 24;

    private final Random rng = new Random();
    private int d1 = 3, d2 = 4, rollTick;
    private boolean showSum = false;
    private ResultPacket pending;

    public DiceScreen(int chips) {
        super(GameType.DICE, chips);
    }

    @Override
    protected String hintKey() { return "gwyf.hint.dice"; }

    @Override
    protected void initGame(int left, int top) {
        addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.under"), b -> roll(0))
                .dimensions(left + 12, top + 156, 94, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.seven"), b -> roll(1))
                .dimensions(left + 113, top + 156, 94, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.over"), b -> roll(2))
                .dimensions(left + 214, top + 156, 94, 20).build());
    }

    private void roll(int choice) {
        if (busy) return;
        if (chips < bet()) {
            setMessage(Text.translatable("gwyf.ui.nochips").getString(), 0xFFFF5555);
            return;
        }
        busy = true;
        chips -= bet();
        message = "";
        pending = null;
        rollTick = 0;
        showSum = false;
        sendAction(Rules.ACT_PLAY, bet(), choice);
        play(SoundEvents.BLOCK_WOODEN_BUTTON_CLICK_ON, 0.8f);
    }

    @Override
    protected void handle(ResultPacket r) {
        if (r.event() == Ev.DICE_RESULT) pending = r;
    }

    @Override
    protected void tickGame() {
        if (!busy) return;
        rollTick++;
        if (rollTick % 3 == 0 && pending == null || rollTick % 3 == 0 && rollTick < ROLL_TICKS) {
            d1 = 1 + rng.nextInt(6);
            d2 = 1 + rng.nextInt(6);
            play(SoundEvents.BLOCK_WOODEN_BUTTON_CLICK_ON, 0.6f + rng.nextFloat() * 0.4f);
        }
        if (pending != null && rollTick >= ROLL_TICKS) {
            d1 = pending.a();
            d2 = pending.b();
            chips = pending.chips();
            showSum = true;
            busy = false;
            if (pending.payout() > 0) {
                setMessage(Text.translatable("gwyf.ui.payout", pending.payout()).getString(), 0xFF55FF55);
                play(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f);
            } else {
                setMessage(Text.translatable("gwyf.ui.lose").getString(), 0xFFFF5555);
                play(SoundEvents.ENTITY_VILLAGER_NO, 1.0f);
            }
            pending = null;
        }
    }

    @Override
    protected void onNoChips() {
        pending = null;
    }

    private void drawDie(DrawContext c, int x, int y, int s, int v) {
        c.fill(x - 2, y - 2, x + s + 2, y + s + 2, 0xFF000000);
        c.fill(x, y, x + s, y + s, 0xFFF5F5F5);
        int ps = Math.max(2, s / 8);
        for (int[] p : PIPS[v]) {
            int cx = x + (int) (s * (0.25 + 0.25 * p[0]));
            int cy = y + (int) (s * (0.25 + 0.25 * p[1]));
            c.fill(cx - ps, cy - ps, cx + ps, cy + ps, 0xFF151515);
        }
    }

    @Override
    protected void drawGame(DrawContext c, int mx, int my, float delta) {
        c.fill(left + 16, top + 28, left + panelW - 16, top + 124, 0xFF0F6A2E); // felt
        int s = 48;
        drawDie(c, left + panelW / 2 - s - 14, top + 42, s, d1);
        drawDie(c, left + panelW / 2 + 14, top + 42, s, d2);
        if (showSum) {
            c.drawCenteredTextWithShadow(textRenderer, Text.translatable("gwyf.ui.sum", d1 + d2), left + panelW / 2, top + 100, 0xFFFFFFFF);
        }
    }
}
