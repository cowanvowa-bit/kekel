package com.gwyf.casino.client;

import com.gwyf.casino.Ev;
import com.gwyf.casino.GameType;
import com.gwyf.casino.ResultPacket;
import com.gwyf.casino.Rules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.Locale;

public class PenguinScreen extends CasinoScreen {
    private boolean running, awaiting;
    private int steps, fellAt = -1, lockedBet, anim;
    private double mult = 1.0;
    private ButtonWidget startBtn, stepBtn, cashBtn;

    public PenguinScreen(int chips) {
        super(GameType.PENGUIN, chips);
    }

    @Override
    protected String hintKey() { return "gwyf.hint.penguin"; }

    @Override
    protected void initGame(int left, int top) {
        startBtn = addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.start"), b -> start())
                .dimensions(left + 15, top + 156, 90, 20).build());
        stepBtn = addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.step"), b -> step())
                .dimensions(left + 115, top + 156, 90, 20).build());
        cashBtn = addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.cashout"), b -> cash())
                .dimensions(left + 215, top + 156, 90, 20).build());
    }

    private void start() {
        if (busy || running) return;
        if (chips < bet()) {
            setMessage(Text.translatable("gwyf.ui.nochips").getString(), 0xFFFF5555);
            return;
        }
        busy = true;
        lockedBet = bet();
        chips -= lockedBet;
        message = "";
        sendAction(Rules.ACT_PLAY, lockedBet, 0);
    }

    private void step() {
        if (!running || awaiting) return;
        awaiting = true;
        sendAction(Rules.ACT_STEP, 0, 0);
    }

    private void cash() {
        if (!running || awaiting || steps == 0) return;
        awaiting = true;
        sendAction(Rules.ACT_CASHOUT, 0, 0);
    }

    @Override
    protected void handle(ResultPacket r) {
        switch (r.event()) {
            case Ev.PENGUIN_STARTED -> {
                busy = false;
                running = true;
                awaiting = false;
                steps = 0;
                fellAt = -1;
                mult = 1.0;
            }
            case Ev.PENGUIN_STEP -> {
                steps = r.a();
                mult = r.mult();
                awaiting = false;
                play(SoundEvents.BLOCK_WOODEN_BUTTON_CLICK_ON, 1.2f);
            }
            case Ev.PENGUIN_FELL -> {
                running = false;
                awaiting = false;
                steps = r.a();
                fellAt = steps + 1;
                chips = r.chips();
                setMessage(Text.translatable("gwyf.ui.fell").getString(), 0xFFFF5555);
                play(SoundEvents.ENTITY_PLAYER_SPLASH, 1.0f);
            }
            case Ev.PENGUIN_CASHED -> {
                running = false;
                awaiting = false;
                steps = r.a();
                mult = r.mult();
                chips = r.chips();
                setMessage(Text.translatable("gwyf.ui.payout", r.payout()).getString(), 0xFF55FF55);
                play(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f);
            }
            default -> {}
        }
    }

    @Override
    protected void onNoChips() {
        running = false;
    }

    @Override
    protected void tickGame() {
        anim++;
        if (startBtn != null) startBtn.active = !running && !busy;
        if (stepBtn != null) stepBtn.active = running && !awaiting;
        if (cashBtn != null) cashBtn.active = running && !awaiting && steps > 0;
    }

    private void penguin(DrawContext c, int cx, int cy) {
        c.fill(cx - 5, cy - 16, cx + 5, cy - 2, 0xFF15151A);   // body
        c.fill(cx - 3, cy - 11, cx + 3, cy - 2, 0xFFFFFFFF);   // belly
        c.fill(cx - 4, cy - 14, cx - 1, cy - 12, 0xFFFFFFFF);  // eyes
        c.fill(cx + 1, cy - 14, cx + 4, cy - 12, 0xFFFFFFFF);
        c.fill(cx - 2, cy - 14, cx - 1, cy - 13, 0xFF000000);
        c.fill(cx + 1, cy - 14, cx + 2, cy - 13, 0xFF000000);
        c.fill(cx - 2, cy - 12, cx + 2, cy - 10, 0xFFFF9A1F);  // beak
        c.fill(cx - 5, cy - 2, cx - 1, cy, 0xFFFF9A1F);        // feet
        c.fill(cx + 1, cy - 2, cx + 5, cy, 0xFFFF9A1F);
    }

    @Override
    protected void drawGame(DrawContext c, int mx, int my, float delta) {
        int tile = 24, gap = 2, n = Rules.PENGUIN_MAX + 1;
        int x0 = left + (panelW - (n * (tile + gap) - gap)) / 2;
        int ty = top + 62;
        c.fill(left + 8, top + 28, left + panelW - 8, top + 124, 0xFF1C4E92); // water
        MatrixStack ms = c.getMatrices();
        for (int i = 0; i < n; i++) {
            int x = x0 + i * (tile + gap);
            int col = i == 0 ? 0xFFB9E3F0 : (i <= steps ? 0xFF9CCDE6 : 0xFFE3F6FF);
            if (i == fellAt) col = 0xFF0A2850;
            c.fill(x, ty, x + tile, ty + tile, col);
            c.fill(x, ty, x + tile, ty + 1, 0xFFFFFFFF);
            if (i == fellAt) {
                c.drawCenteredTextWithShadow(textRenderer, "X", x + tile / 2, ty + 8, 0xFFFF5555);
            }
            if (i > 0) {
                String lbl = String.format(Locale.ROOT, "x%.1f", Rules.penguinMult(i));
                ms.push();
                ms.scale(0.5f, 0.5f, 1f);
                c.drawCenteredTextWithShadow(textRenderer, lbl, (x + tile / 2) * 2, (ty - 10) * 2, 0xFFFFFFFF);
                ms.pop();
            }
        }
        if (fellAt < 0) {
            int bob = (int) Math.round(Math.sin(anim / 4.0) * 1.5);
            penguin(c, x0 + steps * (tile + gap) + tile / 2, ty + tile - 3 + bob);
        }
        if (running && steps > 0) {
            int pot = (int) Math.floor(lockedBet * mult);
            c.drawCenteredTextWithShadow(textRenderer,
                    Text.translatable("gwyf.ui.potential", String.format(Locale.ROOT, "%.2f", mult), pot),
                    left + panelW / 2, top + 104, 0xFFFFFF55);
        }
    }
}
