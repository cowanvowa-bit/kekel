package com.gwyf.casino.client;

import com.gwyf.casino.Ev;
import com.gwyf.casino.GameType;
import com.gwyf.casino.ResultPacket;
import com.gwyf.casino.Rules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CrashScreen extends CasinoScreen {
    private boolean running, crashed, cashPending;
    private int runTicks;
    private double mult = 1.0;
    private int endColor = 0xFFFFFFFF;
    private final List<Double> history = new ArrayList<>();
    private ButtonWidget startBtn, cashBtn;

    public CrashScreen(int chips) {
        super(GameType.CRASH, chips);
    }

    @Override
    protected String hintKey() { return "gwyf.hint.crash"; }

    @Override
    protected void initGame(int left, int top) {
        startBtn = addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.start"), b -> start())
                .dimensions(left + 60, top + 156, 90, 20).build());
        cashBtn = addDrawableChild(ButtonWidget.builder(Text.translatable("gwyf.ui.cashout"), b -> cash())
                .dimensions(left + 170, top + 156, 90, 20).build());
    }

    private void start() {
        if (busy || running) return;
        if (chips < bet()) {
            setMessage(Text.translatable("gwyf.ui.nochips").getString(), 0xFFFF5555);
            return;
        }
        busy = true;
        chips -= bet();
        message = "";
        sendAction(Rules.ACT_PLAY, bet(), 0);
    }

    private void cash() {
        if (!running || cashPending) return;
        cashPending = true;
        sendAction(Rules.ACT_CASHOUT, 0, 0);
    }

    @Override
    protected void handle(ResultPacket r) {
        switch (r.event()) {
            case Ev.CRASH_STARTED -> {
                busy = false;
                running = true;
                crashed = false;
                cashPending = false;
                runTicks = 0;
                mult = 1.0;
                endColor = 0xFFFFFFFF;
                history.clear();
                play(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f);
            }
            case Ev.CRASH_CASHED -> {
                running = false;
                cashPending = false;
                mult = r.mult();
                chips = r.chips();
                endColor = 0xFF55FF55;
                setMessage(Text.translatable("gwyf.ui.cashed", fmt(r.mult()), r.payout()).getString(), 0xFF55FF55);
                play(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f);
            }
            case Ev.CRASH_CRASHED -> {
                running = false;
                crashed = true;
                cashPending = false;
                mult = r.mult();
                chips = r.chips();
                endColor = 0xFFFF5555;
                setMessage(Text.translatable("gwyf.ui.crashed", fmt(r.mult())).getString(), 0xFFFF5555);
                play(SoundEvents.ENTITY_GENERIC_EXPLODE, 1.0f);
            }
            default -> {}
        }
    }

    @Override
    protected void onNoChips() {
        running = false;
    }

    private static String fmt(double m) {
        return String.format(Locale.ROOT, "%.2f", Math.floor(m * 100.0) / 100.0);
    }

    @Override
    protected void tickGame() {
        if (running) {
            runTicks++;
            mult = Rules.crashMult(runTicks);
            history.add(mult);
        }
        if (startBtn != null) startBtn.active = !running && !busy;
        if (cashBtn != null) cashBtn.active = running && !cashPending;
    }

    @Override
    protected void drawGame(DrawContext c, int mx, int my, float delta) {
        int cl = left + 16, cr = left + panelW - 16, ct = top + 28, cb = top + 124;
        c.fill(cl - 1, ct - 1, cr + 1, cb + 1, 0xFF3A4060);
        c.fill(cl, ct, cr, cb, 0xFF080C1A);

        int n = history.size();
        double maxM = Math.max(2.5, mult * 1.15);
        double denom = Math.log(maxM);
        int xs = Math.max(150, n);
        int lastX = cl + 2, lastY = cb - 3;
        for (int i = 0; i < n; i++) {
            double m = history.get(i);
            int px = cl + 2 + (int) ((double) i / xs * (cr - cl - 16));
            int py = cb - 3 - (int) (Math.log(Math.max(1.0, m)) / denom * (cb - ct - 14));
            c.fill(px, py, px + 2, py + 2, crashed ? 0xFFFF4040 : 0xFF39FF14);
            lastX = px;
            lastY = py;
        }
        if (running || crashed) {
            ItemStack icon = new ItemStack(crashed ? Items.TNT : Items.FIREWORK_ROCKET);
            c.drawItem(icon, lastX - 8, lastY - 14);
        }

        String label = fmt(mult) + "x";
        c.getMatrices().push();
        c.getMatrices().scale(3f, 3f, 1f);
        c.drawCenteredTextWithShadow(textRenderer, label, (int) ((left + panelW / 2) / 3f), (int) ((top + 60) / 3f), endColor);
        c.getMatrices().pop();
    }
}
