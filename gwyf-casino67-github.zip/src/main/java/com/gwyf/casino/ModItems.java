package com.gwyf.casino;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {
    private ModItems() {}

    public static final Item CHIP = Registry.register(Registries.ITEM,
            new Identifier(GwyfCasino.MOD_ID, "casino_chip"), new Item(new FabricItemSettings()));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP,
            new Identifier(GwyfCasino.MOD_ID, "main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(CHIP))
                    .displayName(Text.translatable("itemGroup.gwyf.main"))
                    .entries((ctx, entries) -> {
                        entries.add(CHIP);
                        entries.add(ModBlocks.SLOT_MACHINE);
                        entries.add(ModBlocks.CRASH_MACHINE);
                        entries.add(ModBlocks.DICE_MACHINE);
                        entries.add(ModBlocks.PENGUIN_MACHINE);
                    })
                    .build());

    public static void init() {}
}
