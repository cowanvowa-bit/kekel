package com.gwyf.casino;

import net.minecraft.network.PacketByteBuf;

public record ResultPacket(int game, int event, int chips, double mult, int a, int b, int c, int payout) {
    public void write(PacketByteBuf buf) {
        buf.writeInt(game);
        buf.writeInt(event);
        buf.writeInt(chips);
        buf.writeDouble(mult);
        buf.writeInt(a);
        buf.writeInt(b);
        buf.writeInt(c);
        buf.writeInt(payout);
    }

    public static ResultPacket read(PacketByteBuf buf) {
        return new ResultPacket(buf.readInt(), buf.readInt(), buf.readInt(), buf.readDouble(),
                buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt());
    }
}
