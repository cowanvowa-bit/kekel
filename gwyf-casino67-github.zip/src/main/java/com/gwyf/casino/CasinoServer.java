package com.gwyf.casino;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** All game logic runs here, on the server. The client only draws. */
public final class CasinoServer {
    private CasinoServer() {}

    public static final Identifier OPEN = new Identifier(GwyfCasino.MOD_ID, "open");
    public static final Identifier ACTION = new Identifier(GwyfCasino.MOD_ID, "action");
    public static final Identifier RESULT = new Identifier(GwyfCasino.MOD_ID, "result");

    private static final Random RNG = new Random();
    private static final Map<UUID, GameType> OPENED = new HashMap<>();
    private static final Map<UUID, CrashSession> CRASH = new HashMap<>();
    private static final Map<UUID, PenguinSession> PENGUIN = new HashMap<>();

    private static final class CrashSession {
        final int bet, startTick;
        final double crashPoint;
        CrashSession(int bet, int startTick, double crashPoint) {
            this.bet = bet; this.startTick = startTick; this.crashPoint = crashPoint;
        }
    }

    private static final class PenguinSession {
        final int bet;
        int steps;
        PenguinSession(int bet) { this.bet = bet; }
    }

    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(ACTION, (server, player, handler, buf, responseSender) -> {
            int game = buf.readInt();
            int action = buf.readInt();
            int arg = buf.readInt();
            int arg2 = buf.readInt();
            server.execute(() -> handle(player, game, action, arg, arg2));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            settle(handler.player);
            OPENED.remove(handler.player.getUuid());
        });
        ServerTickEvents.END_SERVER_TICK.register(CasinoServer::tick);
    }

    public static void open(ServerPlayerEntity p, GameType g) {
        settle(p);
        OPENED.put(p.getUuid(), g);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(g.id);
        buf.writeInt(ChipUtil.count(p));
        ServerPlayNetworking.send(p, OPEN, buf);
    }

    private static void send(ServerPlayerEntity p, GameType g, int ev, double mult, int a, int b, int c, int payout) {
        PacketByteBuf buf = PacketByteBufs.create();
        new ResultPacket(g.id, ev, ChipUtil.count(p), mult, a, b, c, payout).write(buf);
        ServerPlayNetworking.send(p, RESULT, buf);
    }

    private static void handle(ServerPlayerEntity p, int gameId, int action, int arg, int arg2) {
        GameType g = GameType.byId(gameId);
        if (g == null || OPENED.get(p.getUuid()) != g) return;
        switch (action) {
            case Rules.ACT_CLOSE -> {
                settle(p);
                OPENED.remove(p.getUuid());
            }
            case Rules.ACT_PLAY -> {
                switch (g) {
                    case SLOTS -> slots(p, arg);
                    case DICE -> dice(p, arg, arg2);
                    case CRASH -> crashStart(p, arg);
                    case PENGUIN -> penguinStart(p, arg);
                }
            }
            case Rules.ACT_CASHOUT -> {
                if (g == GameType.CRASH) crashCash(p);
                else if (g == GameType.PENGUIN) penguinCash(p);
            }
            case Rules.ACT_STEP -> {
                if (g == GameType.PENGUIN) penguinStep(p);
            }
            default -> {}
        }
    }

    /** Pays out / refunds running rounds when the player leaves the machine. */
    private static void settle(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        CrashSession c = CRASH.remove(id);
        if (c != null) {
            double m = Rules.crashMult(p.getServer().getTicks() - c.startTick);
            if (m < c.crashPoint) ChipUtil.give(p, (int) Math.floor(c.bet * m));
        }
        PenguinSession s = PENGUIN.remove(id);
        if (s != null) {
            int pay = s.steps == 0 ? s.bet : (int) Math.floor(s.bet * Rules.penguinMult(s.steps));
            ChipUtil.give(p, pay);
        }
    }

    private static void tick(MinecraftServer server) {
        if (CRASH.isEmpty()) return;
        Iterator<Map.Entry<UUID, CrashSession>> it = CRASH.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, CrashSession> e = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            if (p == null) { it.remove(); continue; }
            CrashSession s = e.getValue();
            if (Rules.crashMult(server.getTicks() - s.startTick) >= s.crashPoint) {
                it.remove();
                send(p, GameType.CRASH, Ev.CRASH_CRASHED, s.crashPoint, 0, 0, 0, 0);
            }
        }
    }

    // ---------------- SLOTS ----------------
    private static int pickSymbol() {
        int r = RNG.nextInt(100), acc = 0;
        for (int i = 0; i < Rules.SLOT_WEIGHTS.length; i++) {
            acc += Rules.SLOT_WEIGHTS[i];
            if (r < acc) return i;
        }
        return 0;
    }

    private static void slots(ServerPlayerEntity p, int bet) {
        if (!Rules.validBet(bet)) return;
        if (!ChipUtil.take(p, bet)) { send(p, GameType.SLOTS, Ev.NO_CHIPS, 0, 0, 0, 0, 0); return; }
        int a = pickSymbol(), b = pickSymbol(), c = pickSymbol();
        double mult = 0;
        if (a == b && b == c) mult = Rules.SLOT_THREE[a];
        else if (a == b || a == c) mult = Rules.SLOT_PAIR[a];
        else if (b == c) mult = Rules.SLOT_PAIR[b];
        int payout = (int) Math.floor(bet * mult);
        if (payout > 0) ChipUtil.give(p, payout);
        send(p, GameType.SLOTS, Ev.SLOTS_RESULT, mult, a, b, c, payout);
    }

    // ---------------- DICE ----------------
    private static void dice(ServerPlayerEntity p, int bet, int choice) {
        if (!Rules.validBet(bet) || choice < 0 || choice > 2) return;
        if (!ChipUtil.take(p, bet)) { send(p, GameType.DICE, Ev.NO_CHIPS, 0, 0, 0, 0, 0); return; }
        int d1 = 1 + RNG.nextInt(6), d2 = 1 + RNG.nextInt(6), sum = d1 + d2;
        boolean win = (choice == 0 && sum < 7) || (choice == 1 && sum == 7) || (choice == 2 && sum > 7);
        double mult = choice == 1 ? Rules.DICE_SEVEN : Rules.DICE_SIDE;
        int payout = win ? (int) Math.floor(bet * mult) : 0;
        if (payout > 0) ChipUtil.give(p, payout);
        send(p, GameType.DICE, Ev.DICE_RESULT, win ? mult : 0, d1, d2, choice, payout);
    }

    // ---------------- ROCKET (CRASH) ----------------
    private static void crashStart(ServerPlayerEntity p, int bet) {
        if (!Rules.validBet(bet)) return;
        settle(p);
        if (!ChipUtil.take(p, bet)) { send(p, GameType.CRASH, Ev.NO_CHIPS, 0, 0, 0, 0, 0); return; }
        double r = RNG.nextDouble();
        double cp = Math.min(200.0, Math.max(1.0, Math.floor(96.0 / (1.0 - r)) / 100.0)); // ~4% house edge
        CRASH.put(p.getUuid(), new CrashSession(bet, p.getServer().getTicks(), cp));
        send(p, GameType.CRASH, Ev.CRASH_STARTED, 1.0, 0, 0, 0, 0);
    }

    private static void crashCash(ServerPlayerEntity p) {
        CrashSession s = CRASH.remove(p.getUuid());
        if (s == null) return;
        double m = Rules.crashMult(p.getServer().getTicks() - s.startTick);
        if (m >= s.crashPoint) {
            send(p, GameType.CRASH, Ev.CRASH_CRASHED, s.crashPoint, 0, 0, 0, 0);
            return;
        }
        m = Math.floor(m * 100.0) / 100.0;
        int pay = (int) Math.floor(s.bet * m);
        ChipUtil.give(p, pay);
        send(p, GameType.CRASH, Ev.CRASH_CASHED, m, 0, 0, 0, pay);
    }

    // ---------------- PENGUIN CROSS ----------------
    private static void penguinStart(ServerPlayerEntity p, int bet) {
        if (!Rules.validBet(bet)) return;
        settle(p);
        if (!ChipUtil.take(p, bet)) { send(p, GameType.PENGUIN, Ev.NO_CHIPS, 0, 0, 0, 0, 0); return; }
        PENGUIN.put(p.getUuid(), new PenguinSession(bet));
        send(p, GameType.PENGUIN, Ev.PENGUIN_STARTED, 1.0, 0, 0, 0, 0);
    }

    private static void penguinStep(ServerPlayerEntity p) {
        PenguinSession s = PENGUIN.get(p.getUuid());
        if (s == null) return;
        if (RNG.nextDouble() < Rules.PENGUIN_P) {
            s.steps++;
            if (s.steps >= Rules.PENGUIN_MAX) {
                penguinCash(p);
            } else {
                send(p, GameType.PENGUIN, Ev.PENGUIN_STEP, Rules.penguinMult(s.steps), s.steps, 0, 0, 0);
            }
        } else {
            PENGUIN.remove(p.getUuid());
            send(p, GameType.PENGUIN, Ev.PENGUIN_FELL, 0, s.steps, 0, 0, 0);
        }
    }

    private static void penguinCash(ServerPlayerEntity p) {
        PenguinSession s = PENGUIN.get(p.getUuid());
        if (s == null || s.steps == 0) return;
        PENGUIN.remove(p.getUuid());
        double m = Rules.penguinMult(s.steps);
        int pay = (int) Math.floor(s.bet * m);
        ChipUtil.give(p, pay);
        send(p, GameType.PENGUIN, Ev.PENGUIN_CASHED, m, s.steps, 0, 0, pay);
    }
}
